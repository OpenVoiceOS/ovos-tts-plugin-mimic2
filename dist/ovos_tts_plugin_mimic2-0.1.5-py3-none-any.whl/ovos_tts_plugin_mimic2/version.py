# The following lines are replaced during the release process.
# START_VERSION_BLOCK
VERSION_MAJOR = 0
VERSION_MINOR = 1
VERSION_BUILD = 5
VERSION_ALPHA = 0
# END_VERSION_BLOCK
